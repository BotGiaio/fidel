<?php

return [
    'epayco' => [
        'public_key' => env('EPAYCO_PUBLIC_KEY', 'a56402c37f0febf7cf8d09ad0473a2a0'),
        'private_key' => env('EPAYCO_PRIVATE_KEY', 'b01b23c9504d276b1b008fd60dd301f6'),
        'client_id' => env('EPAYCO_CLIENT_ID', '618946'),
        'p_key' => env('EPAYCO_P_KEY', '5472f5e62563a8b18e4d09ae7b0c959379f732e8'),
    ]
];
