<?php

namespace Modules\EpaycoSubscribe\Database\Seeds;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use App\Models\Plan; // Cambié "Plans" a "Plan"
use App\Models\User;

class EpaycoSubscribeDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        // Sembrar datos de planes
        $this->seedPlans();

        // Sembrar datos de usuarios
        $this->seedUsers();

        Model::reguard();
    }

    protected function seedPlans()
    {
        Plan::create([ // Cambié "Plans" a "Plan"
            'name' => 'Plan Básico',
            'epayco_id' => 'plan_id_1', // Asegúrate de que coincida con el ID de Epayco
            'price' => 10000, // Precio en COP
            'description' => 'Este es un plan básico.',
        ]);

        Plan::create([ // Cambié "Plans" a "Plan"
            'name' => 'Plan Premium',
            'epayco_id' => 'plan_id_2', // Asegúrate de que coincida con el ID de Epayco
            'price' => 20000, // Precio en COP
            'description' => 'Este es un plan premium con más beneficios.',
        ]);
    }

    protected function seedUsers()
    {
        User::create([
            'name' => 'Usuario de Prueba 1',
            'email' => 'usuario1@ejemplo.com',
            'password' => bcrypt('contraseña123'), // Asegúrate de usar bcrypt para las contraseñas
            'plan_id' => null, // Inicialmente sin plan
        ]);

        User::create([
            'name' => 'Usuario de Prueba 2',
            'email' => 'usuario2@ejemplo.com',
            'password' => bcrypt('contraseña123'),
            'plan_id' => null,
        ]);
    }
}
