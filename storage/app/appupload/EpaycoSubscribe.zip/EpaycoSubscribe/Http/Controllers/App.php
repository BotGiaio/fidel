<?php

namespace Modules\EpaycoSubscribe\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User; // Importa el modelo User
use Epayco\Sdk;

class App extends Controller
{
    /**
     * Valida que el usuario tenga una suscripción activa.
     *
     * @param  User  $user
     * @return bool
     * @throws \InvalidArgumentException
     * @throws \Exception
     */
    public function validateSubscription(User $user)
    {
        // Verificar que el usuario no sea nulo
        if (is_null($user)) {
            throw new \InvalidArgumentException('El usuario no puede ser nulo.');
        }

        // Verificar que el usuario tenga un ID
        if (empty($user->id)) {
            throw new \InvalidArgumentException('El usuario debe tener un ID.');
        }

        // Integrar la llamada a la API de Epayco para verificar la suscripción
        $subscriptionStatus = $this->checkEpaycoSubscription($user->id);

        if ($subscriptionStatus !== 'active') {
            throw new \Exception('La suscripción del usuario no está activa.');
        }

        return true; // La validación fue exitosa
    }

    /**
     * Verifica la suscripción de un usuario a través de la API de Epayco.
     *
     * @param  string  $userId
     * @return string
     * @throws \Exception
     */
    private function checkEpaycoSubscription($userId)
    {
        // Configura la conexión con Epayco
        $epayco = new Sdk('public_key', 'private_key');

        try {
            $subscription = $epayco->subscriptions->get($userId);
            return $subscription->status; // Retorna el estado de la suscripción
        } catch (\Exception $e) {
            // Manejo de errores
            throw new \Exception('Error al verificar la suscripción: ' . $e->getMessage());
        }
    }
}
