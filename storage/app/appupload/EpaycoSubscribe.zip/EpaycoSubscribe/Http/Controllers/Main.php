<?php

namespace Modules\EpaycoSubscribe\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use App\Models\Plans;
use App\Models\User;

class Main extends Controller
{
    public function handleEpaycoWebhook(Request $request)
    {
        // Validar que se reciba un correo electrónico
        if (!$request->has('x_customer_email') || !$request->has('x_idfactura') || !$request->has('x_transaction_state')) {
            return response()->json([
                'status' => false,
                'msg' => 'Datos incompletos.',
            ], Response::HTTP_BAD_REQUEST);
        }

        // Email - buscar el usuario
        $email = $request->x_customer_email; // Epayco usa 'x_customer_email'
        $user = User::where('email', $email)->firstOrFail();

        // Plan ID - buscar el plan
        $subscription_plan_id = $request->x_idfactura;  // Epayco usa 'x_idfactura'
        $plan = Plans::where('epayco_id', $subscription_plan_id)->firstOrFail();

        // Estado para decidir la acción
        $status = $request->x_transaction_state;  // Epayco usa 'x_transaction_state'

        // Epayco estados: "Aceptada" (pago exitoso) o "Fallida" (pago fallido)
        if ($status == 'Aceptada') {
            $this->activatePlan($user, $plan, $request);
            return response()->json([
                'status' => true,
                'msg' => 'Plan activado',
            ]);
        } elseif ($status == 'Fallida') {
            $this->removePlan($user);
            return response()->json([
                'status' => true,
                'msg' => 'Plan eliminado',
            ]);
        }

        // Si el estado es otro, manejarlo aquí
        return response()->json([
            'status' => false,
            'msg' => 'Estado no reconocido',
        ], Response::HTTP_BAD_REQUEST);
    }

    private function activatePlan($user, $plan, $request)
    {
        $user->plan_id = $plan->id;
        $user->plan_status = 'active';
        if ($request->has('x_cancel_url') && strlen($request->x_cancel_url)) {
            $user->cancel_url = $request->x_cancel_url;
            $user->update_url = $request->x_update_url;
        }
        $user->subscription_plan_id = $request->x_idfactura; // ID de suscripción de Epayco
        $user->save();
    }

    private function removePlan($user)
    {
        $user->plan_id = null;
        $user->plan_status = '';
        $user->cancel_url = '';
        $user->update_url = '';
        $user->subscription_plan_id = null;
        $user->save();
    }
}
