<?php

namespace Modules\EpaycoSubscribe\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function processPayment(Request $request)
    {
        // Lógica para procesar el pago con Epayco
        // Ejemplo:
        return response()->json(['status' => 'success', 'message' => 'Payment processed']);
    }

    // Agrega más métodos según sea necesario
}
