<?php

namespace Modules\EpaycoSubscribe\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider as Provider;
use Epayco\Epayco;

class Main extends Provider
{
    public function boot()
    {
        $this->loadConfig();
        $this->loadViews();
        $this->loadViewComponents();
        $this->loadTranslations();
        $this->loadMigrations();
    }

    public function register()
    {
        $this->loadRoutes();
        
        // Registro del servicio de ePayco
        $this->app->singleton(Epayco::class, function () {
            return new Epayco([
                'apiKey' => config('epayco.P_PUBLIC_KEY'),
                'privateKey' => config('epayco.P_PRIVATE_KEY'),
                'lang' => 'ES',
                'test' => config('epayco.test_mode', true), // Cambiar a false en producción
            ]);
        });
    }

    protected function loadConfig()
    {
        $this->publishes([
            __DIR__ . '/../Config/config.php' => config_path('epayco-subscribe.php'),
        ], 'config');

        $this->mergeConfigFrom(
            __DIR__ . '/../Config/config.php', 'epayco-subscribe'
        );
    }

    public function loadViews()
    {
        $viewPath = resource_path('views/modules/epayco-subscribe');
        $sourcePath = __DIR__ . '/../Resources/views';

        $this->publishes([$sourcePath => $viewPath], 'views');

        $this->loadViewsFrom(array_merge(array_map(function ($path) {
            return $path . '/modules/epayco-subscribe';
        }, \Config::get('view.paths')), [$sourcePath]), 'epayco-subscribe');
    }

    public function loadViewComponents()
    {
        Blade::componentNamespace('Modules\EpaycoSubscribe\View\Components', 'epayco-subscribe');
    }

    public function loadTranslations()
    {
        $langPath = resource_path('lang/modules/epayco-subscribe');

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, 'epayco-subscribe');
        } else {
            $this->loadTranslationsFrom(__DIR__ . '/../Resources/lang/en', 'epayco-subscribe');
        }
    }

    public function loadMigrations()
    {
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
    }

    public function loadRoutes()
    {
        if (app()->routesAreCached()) {
            return;
        }

        foreach (['web.php', 'api.php'] as $route) {
            $this->loadRoutesFrom(__DIR__ . '/../Routes/' . $route);
        }
    }

    public function provides()
    {
        return [];
    }
}
