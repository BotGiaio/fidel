@if ($user->subscription_active)
    <div class="card-footer py-4">
        <!-- Botón para actualizar suscripción -->
        <a href="javascript:openCheckout('{{ $user->subscription_plan_id }}', '{{ $user->subscription_amount }}', '{{ $user->subscription_plan_name }}')" 
           class="btn btn-warning" 
           aria-label="Actualizar suscripción">
            {{ __('Actualizar suscripción') }}
        </a>

        <!-- Botón para cancelar suscripción -->
        <form action="{{ route('epayco.cancelSubscription', ['plan_id' => $user->subscription_plan_id]) }}" method="POST" class="d-inline">
            @csrf
            <button type="submit" class="btn btn-danger" 
                    aria-label="Cancelar suscripción">
                {{ __('Cancelar suscripción') }}
            </button>
        </form>
    </div>

    @if(session('status'))
        <div class="alert alert-success mt-2">
            {{ session('status') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger mt-2">
            {{ session('error') }}
        </div>
    @endif
@endif
