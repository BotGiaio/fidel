@extends('epayco-subscribe::layouts.master')

@section('content')
    <div class="container">
        <h1>Bienvenido al módulo de suscripciones con ePayco</h1>

        <p>
            Esta vista está cargada desde el módulo: {!! config('epayco-subscribe.name') !!}
        </p>

        <div class="mt-4">
            <h2>Opciones de Suscripción</h2>
            <p>Seleccione una opción para comenzar:</p>
            <a href="{{ route('epayco.viewPlans') }}" class="btn btn-primary">Ver Planes</a>
            @if(auth()->user()->subscription_active)
                <a href="{{ route('epayco.manageSubscription') }}" class="btn btn-warning">Gestionar Suscripción</a>
            @endif
        </div>
    </div>
@endsection
