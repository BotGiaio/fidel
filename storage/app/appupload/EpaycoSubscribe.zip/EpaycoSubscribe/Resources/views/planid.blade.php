<div class="col-md-6">
    <label for="subscribe[epayco_id]">ID del Plan ePayco</label>
    @include('partials.input', [
        'name' => 'ePayco Plan ID',
        'id' => "subscribe[epayco_id]",
        'placeholder' => "ePayco Plan ID aquí...",
        'required' => false,
        'value' => (isset($plan) ? $plan->epayco_id : null)
    ])
</div>
