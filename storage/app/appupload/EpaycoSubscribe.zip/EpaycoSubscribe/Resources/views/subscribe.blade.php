<script src="https://checkout.epayco.co/checkout.js"></script>    
<script type="text/javascript">
    "use strict";

    // Configuración de las credenciales de ePayco desde los valores en config
    var epaycoPublicKey = "{{ config('epayco-subscribe.public_key') }}";
    var currentUserEmail = "{{ auth()->user()->email }}";

    // Configuración del checkout de ePayco
    var handler = ePayco.checkout.configure({
        key: epaycoPublicKey,
        test: true // Cambiar a false en producción
    });

    function openCheckout(planId, amount, description) {
        // Validación de los parámetros
        if (!planId || !amount) {
            alert("ID del plan y monto son requeridos.");
            return;
        }

        // Datos del checkout de ePayco
        handler.open({
            external: "false",
            amount: amount,
            name: "Suscripción " + description,
            description: description,
            currency: "COP",
            country: "CO",
            lang: "es",
            invoice: "12345", // Puedes generar un número dinámico si lo deseas
            extra1: currentUserEmail,
            extra2: planId,
            response: "{{ route('epayco.response') }}", // Ruta de respuesta en tu app
            confirmation: "{{ route('epayco.confirmation') }}", // Ruta de confirmación
            email_billing: currentUserEmail
        });
    }

    // Reemplaza la lógica de planes de Paddle con la lógica de planes de ePayco
    plans.forEach(plan => {
        if (plan.epayco_id != null && user.subscription_plan_id != plan.epayco_id) {
            var buttonName = "{{ __('Cambiar a ') }}" + plan.name;
            $('#button-container-plan-' + plan.id).append("<a href=\"javascript:openCheckout('" + plan.epayco_id + "', '" + plan.amount + "', '" + plan.name + "')\" class=\"btn btn-primary\" aria-label=\"Cambiar a " + plan.name + "\">" + buttonName + "</a>");
        }
    });
</script>
