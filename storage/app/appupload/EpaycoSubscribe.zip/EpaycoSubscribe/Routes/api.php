<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Ruta para obtener información del usuario autenticado
Route::middleware('auth:api')->get('/epayco-subscribe/user', function (Request $request) {
    return response()->json($request->user());
});

// Ruta para suscribirse
Route::middleware('auth:api')->post('/epayco-subscribe/subscribe', function (Request $request) {
    // Lógica para manejar la suscripción
    // Obtén el usuario autenticado
    $user = $request->user();
    
    // Supongamos que recibimos el plan ID desde el request
    $planId = $request->input('plan_id');
    
    // Aquí iría la lógica para crear la suscripción usando Epayco
    // Por ejemplo:
    // $subscription = Epayco::subscribeUser($user, $planId);
    
    return response()->json([
        'status' => true,
        'message' => 'Subscription created',
        // 'data' => $subscription,
    ]);
});

// Ruta para cancelar la suscripción
Route::middleware('auth:api')->post('/epayco-subscribe/cancel', function (Request $request) {
    // Lógica para manejar la cancelación de la suscripción
    $user = $request->user();
    
    // Supongamos que recibimos el ID de la suscripción desde el request
    $subscriptionId = $request->input('subscription_id');
    
    // Aquí iría la lógica para cancelar la suscripción usando Epayco
    // Epayco::cancelSubscription($subscriptionId);
    
    return response()->json([
        'status' => true,
        'message' => 'Subscription canceled',
    ]);
});

// Ruta para listar planes
Route::middleware('auth:api')->get('/epayco-subscribe/plans', function (Request $request) {
    // Aquí iría la lógica para obtener los planes disponibles de Epayco
    // return Plans::all();
    
    return response()->json([
        'status' => true,
        'data' => [
            // Ejemplo de datos de planes
            ['id' => 1, 'name' => 'Plan Básico', 'amount' => 10000],
            ['id' => 2, 'name' => 'Plan Premium', 'amount' => 20000],
        ],
    ]);
});
