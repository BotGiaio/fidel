<?php

use Illuminate\Support\Facades\Route;

Route::group([
    'namespace' => 'Modules\EpaycoSubscribe\Http\Controllers' // Cambia el namespace si es necesario
], function () {

    // Ruta para manejar el webhook de ePayco
    Route::post('/epayco/webhook', 'PaymentController@handleEpaycoWebhook')->name('epayco.webhook');

    // Ruta para cancelar suscripción
    Route::post('/epayco/cancel-subscription/{plan_id}', function ($plan_id, Request $request) {
        // Lógica para cancelar la suscripción
        $user = $request->user();

        // Aquí puedes agregar la lógica para cancelar la suscripción en Epayco
        // Por ejemplo:
        // Epayco::cancelSubscription($user, $plan_id);

        return response()->json([
            'status' => true,
            'message' => 'Subscription canceled',
        ]);
    })->name('epayco.cancelSubscription');

    // Ruta para confirmar el pago y redirigir a la respuesta del usuario
    Route::get('/epayco/response', 'PaymentController@paymentResponse')->name('epayco.response');

    // Ruta para confirmar el pago desde el servidor (e.g., webhook de confirmación)
    Route::post('/epayco/confirmation', 'PaymentController@paymentConfirmation')->name('epayco.confirmation');
});
