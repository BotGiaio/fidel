<?php

return [
    'name' => 'LemonsqueezySubscribe',
    'webhook_secret' => env('LS_WEBHOOK_SECRET')
];
