<?php


namespace Modules\LemonsqueezySubscribe\Http\Controllers;


class App
{
    public function validate($user)
    {
    }
}