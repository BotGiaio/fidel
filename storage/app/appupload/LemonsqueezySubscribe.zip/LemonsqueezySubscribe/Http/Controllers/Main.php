<?php

namespace Modules\LemonsqueezySubscribe\Http\Controllers;

use App\Models\Plans;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Carbon\Carbon;

class Main extends Controller
{
    public function webhook(Request $request)
    {
        //Verify the webhook signature
        $signature = $request->header('X-Signature');
        $payload = $request->getContent();
        $secret = config('lemonsqueezy-subscribe.webhook_secret');
        $computedSignature = hash_hmac('sha256', $payload, $secret);

        if (!hash_equals($computedSignature, $signature)) {
            return response()->json(['message' => 'Invalid signature'], 401);
        }

        //Get the event name
        $event = $request->meta['event_name'];

        //Get the status
        $status = $request->data['attributes']['status'];

        //Get the user
        $user_id = $request->meta['custom_data']['user_id'];
        $user = User::find($user_id);

        //Get the plan
        $plan_id_in_md5 = $request->meta['custom_data']['plan_id'];
        
        //Loop through all plans and find the one that matches the plan_id_in_md5
        $plans = Plans::all();
        foreach($plans as $plan){
            if(md5($plan->id) == $plan_id_in_md5){
                //Break the loop
                break;
            }
        }

        //Update the user's plan
        if($status == 'active' || $event == 'subscription.updated'){
            $user->plan_id = $plan->id;
            $user->plan_status = 'active';
            $user->update_url = $request->data['attributes']['urls']['customer_portal'];
            $user->save();
            return response()->json(['message' => 'Subscription updated'], 200);
        }else if($status == 'cancelled' || $event == 'subscription.updated'){
            $user->plan_status = 'Canceled and active until '.Carbon::parse($request->data['attributes']['ends_at'])->format('F j, Y');;
            $user->save();
            return response()->json(['message' => 'Subscription canceled and active'], 200);
        }else if($event == 'subscription.cancelled'){
            $user->plan_id=null;
            $user->update_url = "";
            $user->plan_status = 'Canceled';
            $user->save();
            return response()->json(['message' => 'Subscription canceled'], 200);
        }

    }

}
