<?php

return [

    'name'              => 'LemonsqueezySubscribe',
    'description'       => 'This is my awesome module',

];