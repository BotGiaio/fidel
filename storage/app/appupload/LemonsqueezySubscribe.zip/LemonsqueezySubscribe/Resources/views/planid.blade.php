<div class="col-md-6">
    @include('partials.input',['name'=>'Lemonsqueezy URL','id'=>"subscribe[ls_id]",'placeholder'=>"Lemonsqueezy Subscription URL",'required'=>false,'value'=>(isset($plan)?$plan->ls_id:null)])
</div>