<?php

namespace Modules\EpaycoSubscribe\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use App\Models\Plans;
use App\Models\User;

class Main extends Controller
{
    public function handleEpaycoWebhook(Request $request)
    {
        // Email - find the user
        $email = $request->x_customer_email; // Epayco usa 'x_customer_email'
        $user = User::where('email', $email)->firstOrFail();

        // Plan ID -- Find the plan
        $subscription_plan_id = $request->x_idfactura;  // Epayco usa 'x_idfactura' como ID de factura
        $plan = Plans::where('epayco_id', $subscription_plan_id)->firstOrFail(); // Cambiar 'paddle_id' a 'epayco_id'

        // Status to decide what to do
        $status = $request->x_transaction_state;  // Epayco usa 'x_transaction_state' para el estado de la transacción

        // Epayco estados: "Aceptada" (pago exitoso) o "Fallida" (pago fallido)
        if ($status == 'Aceptada') {
            // Asignar el plan al usuario
            $user->plan_id = $plan->id;
            $user->plan_status = 'active'; // Puedes asignar "active" o "trialing" si tienes un período de prueba
            if ($request->has('x_cancel_url') && strlen($request->x_cancel_url)) {
                $user->cancel_url = $request->x_cancel_url;
                $user->update_url = $request->x_update_url;
            }
            $user->subscription_plan_id = $request->x_idfactura; // ID de suscripción de Epayco
            $user->update();

            return response()->json([
                'status' => true,
                'msg' => 'Plan activated',
            ]);
        }

        if ($status == 'Fallida') {
            // Remover el plan asignado al usuario si el pago falla
            $user->plan_id = null;
            $user->plan_status = '';
            $user->cancel_url = '';
            $user->update_url = '';
            $user->subscription_plan_id = null;
            $user->update();

            return response()->json([
                'status' => true,
                'msg' => 'Plan removed',
            ]);
        }

        // Si el estado es otro, manejarlo aquí (si es necesario)
    }
}
