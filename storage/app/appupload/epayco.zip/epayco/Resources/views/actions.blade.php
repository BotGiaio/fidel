@if ($user->subscription_active)
    <div class="card-footer py-4">
        <!-- Botón para actualizar suscripción -->
        <a href="javascript:openCheckout('{{ $user->subscription_plan_id }}', '{{ $user->subscription_amount }}', '{{ $user->subscription_plan_name }}')" class="btn btn-warning">
            {{ __('Actualizar suscripción') }}
        </a>

        <!-- Botón para cancelar suscripción -->
        <form action="{{ route('epayco.cancelSubscription', ['plan_id' => $user->subscription_plan_id]) }}" method="POST" class="d-inline">
            @csrf
            <button type="submit" class="btn btn-danger">{{ __('Cancelar suscripción') }}</button>
        </form>
    </div>
@endif