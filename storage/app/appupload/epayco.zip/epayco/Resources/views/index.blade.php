@extends('epayco-subscribe::layouts.master')

@section('content')
    <h1>Bienvenido al módulo de suscripciones con ePayco</h1>

    <p>
        Esta vista está cargada desde el módulo: {!! config('epayco-subscribe.name') !!}
    </p>
@endsection