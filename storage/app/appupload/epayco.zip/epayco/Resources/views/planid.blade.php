<div class="col-md-6">
    @include('partials.input',[
        'name'=>'ePayco Plan ID',
        'id'=>"subscribe[epayco_id]",
        'placeholder'=>"ePayco Plan ID aquí...",
        'required'=>false,
        'value'=>(isset($plan)?$plan->epayco_id:null)
    ])
</div>